# OIBSIP_LandingPage.
Hey Everyone !

During my internship Tenure at Oasis Infobyte, I was fortunate enough to be assigned tasks that were extremely educational and beneficial to my professional development.
I applied for #webdevelopment 
◇ Web Development:
There were 3 tasks given in total and to get our certificates.
we had to perform at least (3 task) for the certification. Overall, it was great learning experience. It was a very
enriching experience as I got the opportunity to work on it.
Overall, my time as an intern at Oasis Infobyte was invaluable, and I am extremely grateful for the opportunity. I am glad to complete this internship and I recommend everyone to grab this amazing opportunity.
LinkedIn Profile : www.linkedin.com/in/sameer-khan-05548622a
◇ Task Details:
Task 1 : Landing Page.
◇ Code Editor : Visual Studio Code
◇ Languages Used : HTML, CSS, Javascript.

#oasisinfobyte is offering us!
To learn more about Oasis Infobyte and to apply for exciting internships, please visit the following website:
https://oasisinfobyte.com/
Do not miss out on this opportunity to gain valuable experience and advance your professional development.
