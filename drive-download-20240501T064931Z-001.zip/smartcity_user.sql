-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: smart-city.ctpu1etrkqud.us-east-1.rds.amazonaws.com    Database: smartcity
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `uid` int NOT NULL AUTO_INCREMENT,
  `first_name` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `last_name` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `user_streetaddress` varchar(65) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `user_city` varchar(45) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `user_zipcode` varchar(45) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `state_ID` int DEFAULT NULL,
  `user_email` varchar(45) COLLATE utf8mb4_general_ci NOT NULL,
  `user_password` varchar(45) COLLATE utf8mb4_general_ci NOT NULL,
  `user_phone` varchar(45) COLLATE utf8mb4_general_ci NOT NULL,
  `role_ID` int DEFAULT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `idUSER_UNIQUE` (`uid`),
  KEY `role_ID_idx` (`role_ID`),
  KEY `state_ID_idx` (`state_ID`),
  CONSTRAINT `role_ID` FOREIGN KEY (`role_ID`) REFERENCES `role` (`role_ID`),
  CONSTRAINT `state_ID` FOREIGN KEY (`state_ID`) REFERENCES `states` (`state_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'Dax','Shethia','52 Tennessee ave','Albany','12206',32,'Dax','1234','3475519946',2),(2,'Maaz','Hussaini','Morton Ave','Albany','12345',32,'maaz','1234','929405932',1),(3,'OweN','Wurster','467 State Route 145','Albany','12345',32,'OwenWurster','1234','1234567809',2),(4,'Kevin','Kev\'a\'rino',NULL,'John','123456',32,'Kevin','1234','',2),(5,'Rahul','Rahul',NULL,'john','123456',32,'Rahul','1234','',1),(6,'Ravi','Teja',NULL,'Albany','12208',32,'Ravi','1234','',2),(7,'Melih','Cartel','Jersey Shore','Jersey','00007',30,'melih','1234','12345654321',2),(8,'OweN','Wurster','467 State Route 145','Albany','12345',32,'OwenWurster','1234','1234567809',2),(9,'kevin','zheng','1234','albany','12208',32,'kevin.zheng2@its.ny.gov','1234','1234567890',1),(10,'Rahul','Sa','1234','Albany','12208',32,'rahuls','5678','9898989898',1),(18,'bob','bob','afbekbkfh','rGgbfdbrge','2',1,'bob','1234','1',2),(19,'Owen','Wurster','461 route 146','guilderland ctr','12085',32,'owen.wurster@its.ny.gov','1234','5166792107',1);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-04-30 20:12:07
