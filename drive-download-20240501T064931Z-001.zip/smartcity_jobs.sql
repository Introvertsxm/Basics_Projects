-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: smart-city.ctpu1etrkqud.us-east-1.rds.amazonaws.com    Database: smartcity
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `job_id` int NOT NULL AUTO_INCREMENT,
  `job_title` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `salary_grade` varchar(10) COLLATE utf8mb4_general_ci NOT NULL,
  `job_agency` varchar(45) COLLATE utf8mb4_general_ci NOT NULL,
  `job_location` varchar(45) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`job_id`)
) ENGINE=InnoDB AUTO_INCREMENT=133734 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
INSERT INTO `jobs` VALUES (126001,'Project Coordinator ','DS','Education Department State','Albany'),(126038,'Professional Engineer 1 ','25','Transportation Department of','Albany'),(126257,'Assistant in Education Improvement Services','18','Education Department State','Albany'),(126397,'Administrative Assistant 1','11','Education Department State','Albany'),(126496,'Licensed Mental Health Counselor','19','Mental Health Office of','Albany'),(126788,'Office Assistant 2','9','Education Department State','Albany'),(126961,'Auditor Trainee 1 ','14','Taxation & Finance State','Albany'),(126964,'Auditor 1 ','18','Taxation & Finance State','Albany'),(127393,'Program Research Specialist 2','23','Education Department State','Albany'),(128178,'Project Assistant','NS','Education Department State','Albany'),(128179,'Project Assistant','NS','Education Department State','Albany'),(128283,'Administrative Assistant 2','15','Education Department State','Albany'),(128454,'Associate in School Nursing','26','Education Department State','Albany'),(128471,'Senior Attorney/Assistant Attorney 1/Assistant Attorney 2/Assistant Attorney 3','25','Medicaid Inspector General NYS Office of the','Albany'),(128490,'Administrative Assistant 2','15','Education Department State','Albany'),(128947,'Information Technology Specialist 2','18','Education Department State','Albany'),(129000,'Education Finance Specialist 1','18','Education Department State','Albany'),(129043,'Senior Accountant','18','Education Department State','Albany'),(129340,'Office Assistant 1','6','Education Department State','Albany'),(129342,'Cleaner ','5','Education Department State','Albany'),(129346,'Associate In Instructional Services ','26','Education Department State','Albany'),(129691,'Food Programs Evaluation Specialist 1','18','Education Department State','Albany'),(130144,'Student Assistant  - 00654','Hourly','Health Department of','Albany'),(130336,'Education Program Assistant 1','14','Education Department State','Albany'),(130338,'Education Program Assistant 1','14','Education Department State','Albany'),(130340,'Education Program Assistant 1','14','Education Department State','Albany'),(130343,'Education Program Assistant 1','14','Education Department State','Albany'),(130657,'Licensing Services Clerk','9','Education Department State','Albany'),(130658,'Licensing Services Clerk','9','Education Department State','Albany'),(130663,'Auditor 1','18','Education Department State','Albany'),(130778,'Office Assistant 2','9','Education Department State','Albany'),(130858,'Administrative Assistant 1','11','Education Department State','Albany'),(130975,'Project Coordinator I','NS','Environmental Facilities Corporation','Albany'),(131041,'Facility Operations Assistant 1 - VID 131041','Hourly','General Services Office of','Albany'),(131168,'Office Assistant 1 Stores/Mail  - VID 131168','NS','General Services Office of','Albany'),(131304,'Office Assistant 1','6','Education Department State','Albany'),(131539,'Deputy Commissioner','667','Taxation & Finance State','Albany'),(131907,'Assistant Engineer ','20','Thruway Authority','Albany'),(132139,'Associate Attorney Tax Enforcement','663','Taxation & Finance State','Albany'),(132212,'Office Assistant 2','9','Education Department State','Albany'),(132334,'Licensing Services Clerk','9','Education Department State','Albany'),(132339,'Licensing Services Clerk','9','Education Department State','Albany'),(132340,'Licensing Services Clerk','9','Education Department State','Albany'),(132341,'Licensing Services Clerk','9','Education Department State','Albany'),(132343,'Licensing Services Clerk','9','Education Department State','Albany'),(132350,'Associate in Education Improvement Services','26','Education Department State','Albany'),(132437,'Licensing Services Clerk','9','Education Department State','Albany'),(132439,'Licensing Services Clerk','9','Education Department State','Albany'),(132440,'Licensing Services Clerk','9','Education Department State','Albany'),(132441,'Licensing Services Clerk','9','Education Department State','Albany'),(132573,'Registered Nurse Supervisor 1 Psychiatric','22','Mental Health Office of','Albany'),(132574,'Trades Specialist','12','Mental Health Office of','Albany'),(132576,'Registered Nurse 1 Psychiatric','18','Mental Health Office of','Albany'),(132577,'Registered Nurse Supervisor 1 Psychiatric','22','Mental Health Office of','Albany'),(132578,'Recreation Therapist','14','Mental Health Office of','Albany'),(132580,'Registered Nurse 1 Psychiatric','18','Mental Health Office of','Albany'),(132666,'Senior Accountant','18','Education Department State','Albany'),(132748,'Code Compliance Specialist 1','18','Thruway Authority','Albany'),(132822,'Assistant in Educational Planning and Evaluation','22','Education Department State','Albany'),(132922,'Investigator','NS','State Inspector General Office of','Albany'),(132941,'Revenue Crimes Specialist 1','18','Taxation & Finance State','Albany'),(132958,'Revenue Crimes Specialist Trainee 1','14','Taxation & Finance State','Albany'),(133065,'Office Assistant 1','6','Education Department State','Albany'),(133079,'Associate Health Care Fiscal Analyst - 63348','23','Health Department of','Albany'),(133089,'Computer Operator','10','Information Technology Services Office of','Albany'),(133139,'Employees’ Retirement System Examiner 1','9','State Comptroller Office of the','Albany'),(133157,'Administrative Assistant 2','15','Education Department State','Albany'),(133162,'Project Assistant','NS','Education Department State','Albany'),(133168,'Education Finance Specialist 1','18','Education Department State','Albany'),(133174,'Supervisor','28','Education Department State','Albany'),(133260,'Project Assistant  Equated to a SG-18','18','State Comptroller Office of the','Albany'),(133519,'Information Technology Specialist 2 ','18','Education Department State','Albany'),(133554,'Information Technology Specialist 2 ','18','Education Department State','Albany'),(133559,'Education Program Assistant 1','14','Education Department State','Albany'),(133733,'Administrative Law Judge','NS','Empire State Development NYS','Albany');
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-04-30 20:12:21
