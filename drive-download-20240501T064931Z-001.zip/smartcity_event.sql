-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: smart-city.ctpu1etrkqud.us-east-1.rds.amazonaws.com    Database: smartcity
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `event`
--

DROP TABLE IF EXISTS `event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event` (
  `event_id` int NOT NULL AUTO_INCREMENT,
  `event_name` varchar(45) NOT NULL,
  `event_location` varchar(45) NOT NULL,
  `event_date` varchar(45) NOT NULL,
  `event_price` double NOT NULL,
  PRIMARY KEY (`event_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3964 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event`
--

LOCK TABLES `event` WRITE;
/*!40000 ALTER TABLE `event` DISABLE KEYS */;
INSERT INTO `event` VALUES (1000,'38th ANNUAL EVENT','76 N Pearl St, Albany, NY','2023-10-19',15),(1140,'CAPITAL PRIDE FESTIVAL','Washington Park','2023-12-15',0),(1142,'2023 COLUMBUS DAY GRAND GALA','257 Washington Ave Ext, Albany, NY','2023-09-21',5),(1187,'HARVEST FESTIVAL','162 NY-236, Clifton Park, NY','2023-10-15',10),(1189,'OLD SONGS MUSIC FESTIVAL','Altamont Fairgrounds','2023-11-01',50),(1211,'UKRAINIAN FESTIVAL','1 Pulaski St, Cohoes, NY','2023-09-30',10),(1266,'ALBANY CHEFS\' FOOD & WINE FESTIVAL','Albany','2023-11-22',20),(1317,'HALLOWEEN & HAUNTED EVENTS','Albany','2023-10-25',5),(1335,'ALBANY RIVERFRONT JAZZ FESTIVAL','Jennings Landing','2023-11-08',10),(1392,'16th ANNUAL FALL FESTIVAL','2725 Mariaville Rd, Schenectady, NY','2023-10-07',10),(1439,'ALBANY BOOK FESTIVAL','1400 Washington Ave, Albany, NY','2023-10-21',5),(1573,'LUPINE FEST','302 Washington Avenue ','2023-10-25',20),(1577,'ALIVE AT FIVE','677 Broadway','2023-10-07',40),(1591,'NYS WRITERS INSTITUTE\'S ALBANY BOOK FESTIVAL','University at Albany ','2023-09-23',10),(1618,'NYS WRITERS INSTITUTE\'S ALBANY FILM FESTIVAL','120 States Street','2023-10-10',25),(1719,'DAD FEST','Washington Park','2023-12-05',5),(1731,'ALBANY LATIN FEST','Washington Park','2023-11-15',5),(1757,'PEARLPALOOZA','Downtown, Albany','2023-11-04',5),(1760,'ALBANY VEGFEST','55 Eagle St, Albany, NY','2023-10-01',10),(1763,'ANNUAL ALBANY TULIP FESTIVAL','15 Western Avenue, Albany','2023-10-31',30),(1822,'ANNUAL OKTOBERFEST 5K','Albany, NY','2023-09-30',5),(1852,'BASEBALL HALL OF FAME INDUCTION WEEKEND','Cooperstown, NY','2023-11-03',35),(1895,'HOLIDAY CELEBRATIONS','Albany','2023-12-31',5),(1977,'LOREENA McKENNITT','Albany, NY','2023-10-15',20),(1986,'ART ON LARK','Lark Street','2023-11-15',10),(2113,'A Night of Comedy with Cash Cab\'s Ben Bailey',' 58 Remsen St','2023-09-29',35),(2147,'Contra Dance Tunes','37 South Main Street','2023-11-04',15),(2163,'JR De Guzman','1 Crossgates Mall Rd','2023-09-30',20),(2228,'Future Concert','25 Western Avenue','2023-09-23',35),(2235,'Blue October','Empire State Plaza','2023-10-01',10),(2264,'Run for Cover: A Tribute Band to Rush!','58 Remsen St','2023-09-30',10),(2292,'Singles Party- Albany War Room Tavern','42 Eagle Street','2023-10-01',0),(2304,'Stand up Comedy- Free Open Mic Night','75 Livingston Ave','2023-10-08',10),(2310,'Soft Machine','339 Central Ave, Albany, NY','2023-10-12',10),(2429,'What the Constitution Means to Me',' 251 N. Pearl St.','2023-10-13',0),(2479,'RaeLynn','30 2nd St, Troy, NY','2023-10-22',25),(2483,'Trivia Night','75 Livingston Ave','2023-10-27',25),(2546,'John Morgan','1 Crossgates Mall Rd','2023-10-22',15),(2551,'Live Music at Emack & Boilo\'s','366 Delaware Ave','2023-10-29',40),(2570,'Monuments','93 N Pearl St, Albany, NY','2023-10-11',30),(2691,'Saturday Night Dance Party. Y2K!','42 Howard St','2023-09-30',10),(2734,'Drum & Dance with Jordan Taylor Hill','56 Second St','2023-10-21',15),(2785,'Lyle Lovett and Chris Isaak','30 2nd St, Troy, NY','2023-10-08',10),(2813,'Great musical concert with Guilherme Arantes',' Empire State Plaza','2023-10-15',25),(2853,'Steve Hackett','S Mall Arterial, Albany, NY','2023-10-10',10),(3004,'Mohawk Towpath Byway Duathlon','660 Riverview Road','2023-12-01',25),(3039,'TRI-CITY VALLEYCATS','80 Vandenburgh Ave, Troy','2023-11-11',30),(3061,'SIENA SAINTS','515 Loudon Road','2023-10-29',45),(3064,'Stillwater Boys Varsity Soccer','3992 NY-2, Troy, NY','2023-11-06',20),(3079,'Albany Boys JV Soccer','1626 Balltown Rd, Niskayuna, NY','2023-11-28',15),(3097,'MCA Girls Varsity Soccer ','374 Loudon Rd, Loudonville, NY','2023-10-31',25),(3169,'Schenectady vs. Ballston Spa Football','220 Ballston Ave, Ballston Spa, NY','2023-10-20',10),(3176,'AAB Boys JV Soccer','2910 US-9, Valatie, NY','2023-11-22',20),(3202,'Albany Sports Card & Memorabilia Show','225 Washington Ave Ext, Albany, NY','2023-12-17',25),(3229,'Flip Cup Friday\'s',' 16 Sheridan Ave','2023-10-06',5),(3326,'THE ALBANY EMPIRE','51 S Pearl St, Albany','2023-10-07',20),(3424,'James Connolly Albany Football Club','20 Frisbie Ave','2023-10-07',25),(3595,'UALBANY ATHLETICS','1400 Washington Ave','2023-10-04',10),(3641,'Albany vs. Burnt Hills-Ballston Lake Football','88 Lake Hill Rd, Burnt Hills, NY','2023-10-06',20),(3787,'CBA Varsity Football','1 Raider Blvd, Albany, NY','2023-11-07',15),(3801,'Cornhole Tournament','188 Route 146','2023-10-31',10),(3847,'HUDSON MOHAWK ROAD RUNNERS CLUB','Airport/ Wolf Road','2023-10-18',10),(3893,'Rhode Island Rams vs. Albany Great Danes','1400 Washington Ave, Albany, NY','2023-10-21',10),(3963,'THE CHRISTIAN PLUMERI SPORTS COMPLEX','20 Frisbie Ave','2023-10-28',15);
/*!40000 ALTER TABLE `event` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-04-30 20:12:10
