-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: smart-city.ctpu1etrkqud.us-east-1.rds.amazonaws.com    Database: smartcity
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `hotel`
--

DROP TABLE IF EXISTS `hotel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hotel` (
  `hotel_id` int NOT NULL AUTO_INCREMENT,
  `hotel_name` varchar(45) COLLATE utf8mb4_general_ci NOT NULL,
  `hotel_location` varchar(45) COLLATE utf8mb4_general_ci NOT NULL,
  `hotel_price` decimal(10,0) NOT NULL,
  `hotel_room_no` int NOT NULL,
  `hotel_availibility` int NOT NULL,
  PRIMARY KEY (`hotel_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2551 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hotel`
--

LOCK TABLES `hotel` WRITE;
/*!40000 ALTER TABLE `hotel` DISABLE KEYS */;
INSERT INTO `hotel` VALUES (2526,'Choice Hotels & Suites','15 Washington Ave, Albany, NY, 12203',150,109,60),(2527,'Hyatt Hotels & Resorts','16 Washington Ave, Albany, NY, 12209',300,504,37),(2528,'Quality Inn Express ','17 Central Ave, Albany NY, 12208',100,103,55),(2533,'Trident Hotels & Resorts','14 Western Ave, Albany, NY, 12201',250,109,59),(2535,'Days Inn Express ','12 Washington Ave, Albany, NY, 12204',95,109,55),(2536,'Comfort Inn Suites','115 Madison Ave, Albany, NY, 12206',110,109,44),(2537,'Hilton Hotels','17 Central Ave, Albany, NY, 12206',259,109,49),(2539,'Holiday Inn Express & Suites Albany','16 Wolf Rd, Albany, NY 12205',118,446,66),(2540,'Hampton Inn & Suites Albany-Downtown','25 Chapel St, Albany, NY 12210',116,109,35),(2541,'Ramada Plaza by Wyndham Albany','3 Watervliet Ave Ext, Albany, NY 12206',55,222,22),(2542,'Homewood Suites by Hilton Albany','216 Wolf Rd, Albany, NY 12205',144,124,17),(2543,'La Quinta Inn & Suites by Wyndham','833 Loudon Rd, Latham, NY 12110',110,107,33),(2544,'Renaissance Albany Hotel','144 State St, Albany, NY 12207',238,332,21),(2545,'Hampton Inn Albany-Wolf Road (Airport)','10 Ulenski Dr, Albany, NY 12205',109,108,15),(2546,'SureStay Plus By Best Western Albany Airport','200 Wolf Rd, Albany, NY 12205',73,120,73),(2547,'Comfort Inn Latham - Albany North','981 Loudon Rd, Cohoes, NY 12047',74,102,11),(2548,'Crowne Plaza Albany','660 Albany Shaker Rd, Albany, NY 12211',141,34,9),(2549,'Extended Stay America','1395 Washington Ave, Albany, NY 12206',98,111,18),(2550,'Ecno Lodge Inn & Suites',' 1630 Central Ave, Albany, NY 12205',84,123,95);
/*!40000 ALTER TABLE `hotel` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-04-30 20:12:08
